# تنظیمات OpenProject
OP_BASE_URL = 'http://karban.jaboun.network'
CLIENT_ID = 'UlsOOwE8Tun_CIFPRCoP3aLsVWyI1RRmzmBlTRbdClk'
CLIENT_SECRET = 'QosufrY3lq3_Ypd7T5Yn7al7kjUNlQs-qGiRA4_ZwuU'
REDIRECT_URI = 'http://localhost:5000/'

# تنظیمات برنامه
SECRET_KEY = 'my-super-secret-key-12345-change-in-production'
DEBUG = True
